# Contents

These three files list the implicated SNP-gene pairs for the Positional + eSNPs assignment results. The LD loci were selected using AdaPT with target FDR level alpha = 0.05. Each CSV files corresponds to the results for three phenotypes (ASD, SCZ, EA) with r^2 threshold of 0.25 for forming the LD loci. The file names are structured as `phenotype_rsquared25.csv` where phenotype is either `asd`, `scz`, or `ea`.

# Column key

+ ld_loci_id : Unique identifier for the LD loci the gene was assigned to. It has the form `chrA_B` where `A` indicates the chromosome the LD loci is located on and `B` is a unique identifier for that chromosome

+ rsid : SNP rs ID

+ chr : Chromosome SNP is located on

+ bp : SNP's genomic position with genome build hg38

+ a1 : Reference allele (may or may not be minor allele)

+ a2 : Alternative allele

+ ensembl_id : Gene Ensembl ID the SNP is assigned to (SNPs can be assigned to multiple genes resulting in more than one row for a specified SNP rsid)

+ phenotype_or, phenotype_beta, phenotype_se, phenotype_p : Reported odds ratio or slope, standard error, p-value for the three different phenotypes (asd, scz, ea)
