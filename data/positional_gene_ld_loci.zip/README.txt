# Contents

These six files list the implicated genes for the Positional assignment results. The LD loci were selected using AdaPT with target FDR level alpha = 0.05. Each CSV files corresponds to the results for three phenotypes (ASD, SCZ, EA) with two different r^2 thresholds for forming the LD loci. The file names are structured as `phenotype_rsquaredXX.csv` where phenotype is either `asd`, `scz`, or `ea` and `XX` is either `25` or `50` corresponding to r^2 thresholds of 0.25 and 0.50 respectively.

# Column key

+ ensembl_id : Gene Ensembl ID

+ ld_loci_id : Unique identifier for the LD loci the gene was assigned to. It has the form `chrA_B` where `A` indicates the chromosome the LD loci is located on and `B` is a unique identifier for that chromosome

+ gene_chr : Chromosome the gene is located on

+ start : Start position for gene from GENCODE v21 with genome build hg38

+ end: End position for gene from GENCODE v21 with genome build hg38

+ gene_name : Gene’s name

+ gene_biotype : One of four gene biotype classifications based on GENCODE biotypes (`protein_coding`, `lnc_rna`, `antisense`, or `other`)